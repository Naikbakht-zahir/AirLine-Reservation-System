from flask import Flask, render_template, request, redirect, url_for, flash
import pymysql
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'airline123'

def get_db():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='nadia',
        database='airline_db',
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/flights', methods=['GET', 'POST'])
def flights():
    db = get_db()
    cursor = db.cursor()

    if request.method == 'POST':
        from_city = request.form['from_city']
        to_city = request.form['to_city']
        
        cursor.execute("""
            SELECT f.flight_id, f.flight_no, a1.city AS from_city,
                   a2.city AS to_city, f.departure_dt, f.arrival_dt,
                   f.base_price_economy, f.base_price_business, f.base_price_first,
                   ac.model
            FROM flights f
            JOIN airports a1 ON f.origin_id = a1.airport_id
            JOIN airports a2 ON f.dest_id = a2.airport_id
            JOIN aircraft ac ON f.aircraft_id = ac.aircraft_id
            WHERE a1.city = %s AND a2.city = %s AND f.departure_dt > NOW()
            ORDER BY f.departure_dt
        """, (from_city, to_city))
    else:
        cursor.execute("""
            SELECT f.flight_id, f.flight_no, a1.city AS from_city,
                   a2.city AS to_city, f.departure_dt, f.arrival_dt,
                   f.base_price_economy, f.base_price_business, f.base_price_first,
                   ac.model
            FROM flights f
            JOIN airports a1 ON f.origin_id = a1.airport_id
            JOIN airports a2 ON f.dest_id = a2.airport_id
            JOIN aircraft ac ON f.aircraft_id = ac.aircraft_id
            WHERE f.departure_dt > NOW()
            LIMIT 20
        """)

    all_flights = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('flights.html', flights=all_flights)

@app.route('/book/<int:flight_id>', methods=['GET', 'POST'])
def book(flight_id):
    db = get_db()
    cursor = db.cursor()

    if request.method == 'POST':
        full_name = request.form['full_name']
        passport = request.form['passport']
        email = request.form['email']
        phone = request.form['phone']
        seat_no = request.form['seat_no']
        seat_class = request.form['class']
        
        cursor.execute("""
            SELECT base_price_economy, base_price_business, base_price_first 
            FROM flights WHERE flight_id = %s
        """, (flight_id,))
        prices = cursor.fetchone()
        
        if seat_class == 'Economy':
            price_paid = prices['base_price_economy']
        elif seat_class == 'Business':
            price_paid = prices['base_price_business']
        else:
            price_paid = prices['base_price_first']

        cursor.execute("SELECT passenger_id FROM passengers WHERE passport_no = %s", (passport,))
        existing = cursor.fetchone()

        if existing:
            passenger_id = existing['passenger_id']
        else:
            cursor.execute("""
                INSERT INTO passengers (full_name, passport_no, email, phone)
                VALUES (%s, %s, %s, %s)
            """, (full_name, passport, email, phone))
            passenger_id = cursor.lastrowid

        cursor.execute("SELECT booking_id FROM bookings WHERE flight_id = %s AND seat_no = %s AND status = 'Confirmed'", (flight_id, seat_no))
        
        if cursor.fetchone():
            flash('This seat is already booked!', 'danger')
            cursor.close()
            db.close()
            return redirect(url_for('book', flight_id=flight_id))

        cursor.execute("""
            INSERT INTO bookings (passenger_id, flight_id, seat_no, class, status, price_paid)
            VALUES (%s, %s, %s, %s, 'Confirmed', %s)
        """, (passenger_id, flight_id, seat_no, seat_class, price_paid))

        db.commit()
        cursor.close()
        db.close()
        
        flash('Booking confirmed! ✅', 'success')
        return redirect(url_for('bookings'))

    cursor.execute("""
        SELECT f.*, a1.city AS from_city, a2.city AS to_city, ac.model,
               f.base_price_economy, f.base_price_business, f.base_price_first
        FROM flights f
        JOIN airports a1 ON f.origin_id = a1.airport_id
        JOIN airports a2 ON f.dest_id = a2.airport_id
        JOIN aircraft ac ON f.aircraft_id = ac.aircraft_id
        WHERE f.flight_id = %s
    """, (flight_id,))
    flight = cursor.fetchone()
    
    cursor.close()
    db.close()
    return render_template('book.html', flight=flight)

@app.route('/bookings')
def bookings():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        SELECT b.booking_id, p.full_name, f.flight_no,
               a1.city AS from_city, a2.city AS to_city,
               b.seat_no, b.class, b.status, b.price_paid, b.booked_at
        FROM bookings b
        JOIN passengers p ON b.passenger_id = p.passenger_id
        JOIN flights f ON b.flight_id = f.flight_id
        JOIN airports a1 ON f.origin_id = a1.airport_id
        JOIN airports a2 ON f.dest_id = a2.airport_id
        ORDER BY b.booked_at DESC
    """)
    all_bookings = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('bookings.html', bookings=all_bookings)

@app.route('/cancel/<int:booking_id>')
def cancel(booking_id):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("UPDATE bookings SET status='Cancelled' WHERE booking_id = %s", (booking_id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Booking cancelled!', 'danger')
    return redirect(url_for('bookings'))

@app.route('/dashboard')
def dashboard():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT COUNT(*) AS total FROM bookings WHERE status='Confirmed'")
    total_bookings = cursor.fetchone()['total']
    cursor.execute("SELECT COALESCE(SUM(price_paid), 0) AS revenue FROM bookings WHERE status='Confirmed'")
    total_revenue = cursor.fetchone()['revenue']
    cursor.execute("""
        SELECT f.flight_no, a1.city AS from_city, a2.city AS to_city,
               COUNT(b.booking_id) AS bookings, COALESCE(SUM(b.price_paid), 0) AS revenue
        FROM flights f
        LEFT JOIN bookings b ON f.flight_id = b.flight_id AND b.status = 'Confirmed'
        JOIN airports a1 ON f.origin_id = a1.airport_id
        JOIN airports a2 ON f.dest_id = a2.airport_id
        GROUP BY f.flight_id
    """)
    flight_stats = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('dashboard.html', total_bookings=total_bookings, total_revenue=total_revenue, flight_stats=flight_stats)

if __name__ == '__main__':
    app.run(debug=True, port=5001)