✈️ SkyWings Airlines - Flight Booking System

A complete flight booking system with MySQL database. Bookings are permanently saved in database.

 🚀 Quick Start

1. Install Required Software
    - Python 3.8+ (https://www.python.org/downloads/)
    - XAMPP (https://www.apachefriends.org/)

2. Start MySQL
    Open XAMPP Control Panel → Click "Start" on MySQL

3. Open Terminal in Project Folder

4. Create Virtual Environment
    python -m venv venv
    venv\Scripts\activate        # Windows
    source venv/bin/activate     # Mac/Linux

5. Install Flask and MySQL Library
    pip install flask pymysql

6. Setup Database
    python simple_setup.py

7. Run Application
    python app.py

8. Open Browser
    Go to: http://localhost:5001

📁 Project Files:
Create these files in your project folder:

File	                      Description
app.py	                    Main application
simple_setup.py	            Database setup script
templates/base.html	        Layout template
templates/index.html	    Homepage
templates/flights.html	    Flight listing
templates/book.html	        Booking form
templates/bookings.html	    View bookings
templates/dashboard.html	Admin dashboard
README.md	                This file

💻 How to Use:

Action	                            Steps
Search Flights	            Select From/To cities → Click Search
Book Flight	                Click Book Now → Fill details → Confirm
View Bookings	            Click "My Bookings" in navbar
Cancel Booking	            Go to My Bookings → Click Cancel
Admin Dashboard	            Go to http://localhost:5001/dashboard

🔧 Fix Common Errors:

Error	                            Solution
Access denied	            Change password 'nadia' to your MySQL password in both files
Can't connect	            Start MySQL in XAMPP
No module pymysql	        Run pip install pymysql

📊 Check Database:

mysql -u root -p
USE airline_db;
SELECT * FROM bookings;

✅ Features:

* Bookings saved permanently in database

* Economy/Business/First class pricing

* Search flights by city

* Cancel bookings

* Admin dashboard with revenue

* No data loss on refresh

Run: python app.py → Open http://localhost:5001


Final Folder Structure After Creating All Files:

        airline_project/
        ├── app.py
        ├── simple_setup.py
        ├── README.md
        └── templates/
            ├── base.html
            ├── index.html
            ├── flights.html
            ├── book.html
            ├── bookings.html
            └── dashboard.html



