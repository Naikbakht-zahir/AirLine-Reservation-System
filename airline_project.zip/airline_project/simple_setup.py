import pymysql
from datetime import datetime, timedelta

conn = pymysql.connect(
    host='localhost',
    user='root',
    password='nadia',
    charset='utf8mb4',
    cursorclass=pymysql.cursors.DictCursor
)

cursor = conn.cursor()

# Drop and create database
cursor.execute("DROP DATABASE IF EXISTS airline_db")
cursor.execute("CREATE DATABASE airline_db")
cursor.execute("USE airline_db")

# Create tables
cursor.execute("""
CREATE TABLE airports (
    airport_id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(10),
    city VARCHAR(100),
    country VARCHAR(100)
)
""")

cursor.execute("""
CREATE TABLE aircraft (
    aircraft_id INT PRIMARY KEY AUTO_INCREMENT,
    model VARCHAR(100),
    capacity INT
)
""")

cursor.execute("""
CREATE TABLE flights (
    flight_id INT PRIMARY KEY AUTO_INCREMENT,
    flight_no VARCHAR(20),
    origin_id INT,
    dest_id INT,
    aircraft_id INT,
    departure_dt DATETIME,
    arrival_dt DATETIME,
    base_price_economy INT,
    base_price_business INT,
    base_price_first INT,
    FOREIGN KEY (origin_id) REFERENCES airports(airport_id),
    FOREIGN KEY (dest_id) REFERENCES airports(airport_id),
    FOREIGN KEY (aircraft_id) REFERENCES aircraft(aircraft_id)
)
""")

cursor.execute("""
CREATE TABLE passengers (
    passenger_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100),
    passport_no VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20)
)
""")

cursor.execute("""
CREATE TABLE bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    passenger_id INT,
    flight_id INT,
    seat_no VARCHAR(10),
    class VARCHAR(20),
    status VARCHAR(20),
    price_paid INT,
    booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id),
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id)
)
""")

# Insert all airports
airports = [
    # Pakistan
    ('KHI', 'Karachi', 'Pakistan'),
    ('LHE', 'Lahore', 'Pakistan'),
    ('ISB', 'Islamabad', 'Pakistan'),
    ('PEW', 'Peshawar', 'Pakistan'),
    ('UET', 'Quetta', 'Pakistan'),
    ('MUX', 'Multan', 'Pakistan'),
    # Middle East
    ('DXB', 'Dubai', 'UAE'),
    ('AUH', 'Abu Dhabi', 'UAE'),
    ('RUH', 'Riyadh', 'Saudi Arabia'),
    ('JED', 'Jeddah', 'Saudi Arabia'),
    ('DOH', 'Doha', 'Qatar'),
    ('KWI', 'Kuwait City', 'Kuwait'),
    ('MCT', 'Muscat', 'Oman'),
    ('BAH', 'Bahrain', 'Bahrain'),
    # Europe
    ('LHR', 'London', 'UK'),
    ('CDG', 'Paris', 'France'),
    ('FRA', 'Frankfurt', 'Germany'),
    ('AMS', 'Amsterdam', 'Netherlands'),
    ('MAD', 'Madrid', 'Spain'),
    ('FCO', 'Rome', 'Italy'),
    ('MAN', 'Manchester', 'UK'),
    # Asia
    ('IST', 'Istanbul', 'Turkey'),
    ('BKK', 'Bangkok', 'Thailand'),
    ('KUL', 'Kuala Lumpur', 'Malaysia'),
    ('SIN', 'Singapore', 'Singapore'),
    ('HND', 'Tokyo', 'Japan'),
    ('ICN', 'Seoul', 'South Korea'),
    # Americas
    ('JFK', 'New York', 'USA'),
    ('YYZ', 'Toronto', 'Canada'),
    ('ORD', 'Chicago', 'USA'),
    ('LAX', 'Los Angeles', 'USA'),
]

cursor.executemany("INSERT INTO airports (code, city, country) VALUES (%s, %s, %s)", airports)

# Insert aircraft
aircraft = [
    ('Airbus A320', 180),
    ('Boeing 737-800', 162),
    ('Airbus A321', 200),
    ('Boeing 787 Dreamliner', 290),
    ('Airbus A330-300', 277),
    ('Boeing 777-300ER', 354),
]

cursor.executemany("INSERT INTO aircraft (model, capacity) VALUES (%s, %s)", aircraft)

# Get airport IDs dictionary
cursor.execute("SELECT airport_id, city FROM airports")
airport_ids = {row['city']: row['airport_id'] for row in cursor.fetchall()}

# Get aircraft IDs
cursor.execute("SELECT aircraft_id FROM aircraft")
aircraft_list = [row['aircraft_id'] for row in cursor.fetchall()]

# Flight data with ALL combinations
today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

flights_data = [
    # ==================== DOMESTIC PAKISTAN (ALL COMBINATIONS) ====================
    # From Karachi
    ('SW-101', 'Karachi', 'Lahore', 18000, 45000, 72000, 8, 0, 9, 30, 0),
    ('SW-102', 'Karachi', 'Islamabad', 21000, 52500, 84000, 14, 0, 16, 0, 1),
    ('SW-103', 'Karachi', 'Quetta', 15000, 37500, 60000, 7, 0, 8, 15, 2),
    ('SW-104', 'Karachi', 'Multan', 16000, 40000, 64000, 11, 0, 12, 30, 3),
    ('SW-105', 'Karachi', 'Peshawar', 22000, 55000, 88000, 8, 0, 10, 30, 4),
    
    # From Lahore
    ('SW-106', 'Lahore', 'Karachi', 18000, 45000, 72000, 10, 0, 11, 30, 5),
    ('SW-107', 'Lahore', 'Islamabad', 12000, 30000, 48000, 15, 0, 16, 0, 0),
    ('SW-108', 'Lahore', 'Quetta', 19000, 47500, 76000, 13, 0, 14, 45, 1),
    ('SW-109', 'Lahore', 'Multan', 10000, 25000, 40000, 12, 0, 13, 0, 2),
    ('SW-110', 'Lahore', 'Peshawar', 14000, 35000, 56000, 16, 0, 17, 15, 3),
    
    # From Islamabad
    ('SW-111', 'Islamabad', 'Karachi', 21000, 52500, 84000, 17, 0, 19, 0, 4),
    ('SW-112', 'Islamabad', 'Lahore', 12000, 30000, 48000, 16, 30, 17, 30, 5),
    ('SW-113', 'Islamabad', 'Quetta', 18000, 45000, 72000, 14, 0, 15, 45, 0),
    ('SW-114', 'Islamabad', 'Multan', 15000, 37500, 60000, 10, 0, 11, 30, 1),
    ('SW-115', 'Islamabad', 'Peshawar', 8000, 20000, 32000, 9, 0, 9, 45, 2),
    
    # From Quetta
    ('SW-116', 'Quetta', 'Karachi', 15000, 37500, 60000, 9, 0, 10, 15, 3),
    ('SW-117', 'Quetta', 'Lahore', 19000, 47500, 76000, 7, 0, 8, 45, 4),
    ('SW-118', 'Quetta', 'Islamabad', 18000, 45000, 72000, 11, 0, 12, 45, 5),
    ('SW-119', 'Quetta', 'Multan', 13000, 32500, 52000, 13, 0, 14, 15, 0),
    
    # From Multan
    ('SW-120', 'Multan', 'Karachi', 16000, 40000, 64000, 13, 0, 14, 30, 1),
    ('SW-121', 'Multan', 'Lahore', 10000, 25000, 40000, 15, 0, 16, 0, 2),
    ('SW-122', 'Multan', 'Islamabad', 15000, 37500, 60000, 17, 0, 18, 30, 3),
    ('SW-123', 'Multan', 'Quetta', 13000, 32500, 52000, 8, 0, 9, 15, 4),
    
    # From Peshawar
    ('SW-124', 'Peshawar', 'Karachi', 22000, 55000, 88000, 11, 0, 13, 30, 5),
    ('SW-125', 'Peshawar', 'Lahore', 14000, 35000, 56000, 14, 0, 15, 15, 0),
    ('SW-126', 'Peshawar', 'Islamabad', 8000, 20000, 32000, 12, 0, 12, 45, 1),
    
    # ==================== MIDDLE EAST (ALL CITIES FROM/TO PAKISTAN) ====================
    # From Karachi to Middle East
    ('SW-201', 'Karachi', 'Dubai', 55000, 137500, 220000, 2, 0, 4, 30, 2),
    ('SW-202', 'Karachi', 'Abu Dhabi', 53000, 132500, 212000, 1, 0, 3, 30, 3),
    ('SW-203', 'Karachi', 'Riyadh', 52000, 130000, 208000, 3, 0, 5, 30, 4),
    ('SW-204', 'Karachi', 'Jeddah', 65000, 162500, 260000, 15, 0, 18, 0, 5),
    ('SW-205', 'Karachi', 'Doha', 48000, 120000, 192000, 4, 0, 6, 0, 0),
    ('SW-206', 'Karachi', 'Kuwait City', 50000, 125000, 200000, 5, 0, 7, 30, 1),
    ('SW-207', 'Karachi', 'Muscat', 45000, 112500, 180000, 6, 0, 8, 0, 2),
    ('SW-208', 'Karachi', 'Bahrain', 47000, 117500, 188000, 7, 0, 9, 0, 3),
    
    # From Lahore to Middle East
    ('SW-209', 'Lahore', 'Dubai', 60000, 150000, 240000, 20, 0, 22, 30, 4),
    ('SW-210', 'Lahore', 'Abu Dhabi', 58000, 145000, 232000, 21, 0, 23, 30, 5),
    ('SW-211', 'Lahore', 'Riyadh', 57000, 142500, 228000, 22, 0, 0, 30, 0),
    ('SW-212', 'Lahore', 'Jeddah', 70000, 175000, 280000, 22, 0, 2, 0, 1),
    ('SW-213', 'Lahore', 'Doha', 53000, 132500, 212000, 23, 0, 1, 30, 2),
    ('SW-214', 'Lahore', 'Kuwait City', 55000, 137500, 220000, 0, 0, 2, 30, 3),
    
    # From Islamabad to Middle East
    ('SW-215', 'Islamabad', 'Dubai', 58000, 145000, 232000, 23, 0, 1, 30, 4),
    ('SW-216', 'Islamabad', 'Abu Dhabi', 56000, 140000, 224000, 22, 0, 0, 30, 5),
    ('SW-217', 'Islamabad', 'Riyadh', 55000, 137500, 220000, 21, 0, 23, 30, 0),
    ('SW-218', 'Islamabad', 'Jeddah', 68000, 170000, 272000, 20, 0, 23, 30, 1),
    ('SW-219', 'Islamabad', 'Doha', 51000, 127500, 204000, 19, 0, 21, 30, 2),
    
    # From Peshawar to Middle East
    ('SW-220', 'Peshawar', 'Dubai', 59000, 147500, 236000, 18, 0, 20, 30, 3),
    ('SW-221', 'Peshawar', 'Riyadh', 56000, 140000, 224000, 17, 0, 19, 30, 4),
    
    # From Quetta to Middle East
    ('SW-222', 'Quetta', 'Dubai', 54000, 135000, 216000, 16, 0, 18, 30, 5),
    ('SW-223', 'Quetta', 'Muscat', 44000, 110000, 176000, 15, 0, 17, 0, 0),
    
    # Middle East to Middle East
    ('SW-224', 'Dubai', 'Doha', 12000, 30000, 48000, 9, 0, 10, 0, 1),
    ('SW-225', 'Dubai', 'Riyadh', 11000, 27500, 44000, 11, 0, 12, 0, 2),
    ('SW-226', 'Dubai', 'Kuwait City', 13000, 32500, 52000, 13, 0, 14, 30, 3),
    ('SW-227', 'Doha', 'Dubai', 12000, 30000, 48000, 15, 0, 16, 0, 4),
    
    # Middle East to Pakistan (Return flights)
    ('SW-228', 'Dubai', 'Karachi', 55000, 137500, 220000, 6, 0, 8, 30, 5),
    ('SW-229', 'Dubai', 'Lahore', 60000, 150000, 240000, 7, 0, 9, 30, 0),
    ('SW-230', 'Dubai', 'Islamabad', 58000, 145000, 232000, 8, 0, 10, 30, 1),
    
    # ==================== EUROPE (ALL CITIES FROM/TO PAKISTAN) ====================
    # From Karachi to Europe
    ('SW-301', 'Karachi', 'London', 120000, 300000, 480000, 4, 0, 8, 30, 2),
    ('SW-302', 'Karachi', 'Paris', 115000, 287500, 460000, 5, 0, 9, 30, 3),
    ('SW-303', 'Karachi', 'Frankfurt', 110000, 275000, 440000, 6, 0, 10, 0, 4),
    ('SW-304', 'Karachi', 'Amsterdam', 112000, 280000, 448000, 7, 0, 11, 0, 5),
    ('SW-305', 'Karachi', 'Rome', 108000, 270000, 432000, 8, 0, 12, 0, 0),
    ('SW-306', 'Karachi', 'Madrid', 118000, 295000, 472000, 9, 0, 13, 0, 1),
    ('SW-307', 'Karachi', 'Manchester', 115000, 287500, 460000, 10, 0, 14, 0, 2),
    
    # From Lahore to Europe
    ('SW-308', 'Lahore', 'London', 125000, 312500, 500000, 3, 0, 7, 30, 3),
    ('SW-309', 'Lahore', 'Manchester', 115000, 287500, 460000, 4, 30, 9, 0, 4),
    ('SW-310', 'Lahore', 'Paris', 120000, 300000, 480000, 5, 0, 9, 0, 5),
    ('SW-311', 'Lahore', 'Frankfurt', 115000, 287500, 460000, 6, 0, 10, 0, 0),
    
    # From Islamabad to Europe
    ('SW-312', 'Islamabad', 'London', 125000, 312500, 500000, 3, 0, 7, 30, 1),
    ('SW-313', 'Islamabad', 'Paris', 118000, 295000, 472000, 4, 0, 8, 0, 2),
    ('SW-314', 'Islamabad', 'Frankfurt', 113000, 282500, 452000, 5, 0, 9, 0, 3),
    
    # Europe to Pakistan (Return flights)
    ('SW-315', 'London', 'Karachi', 120000, 300000, 480000, 21, 0, 7, 0, 4),
    ('SW-316', 'London', 'Lahore', 125000, 312500, 500000, 22, 0, 8, 0, 5),
    ('SW-317', 'London', 'Islamabad', 125000, 312500, 500000, 23, 0, 9, 0, 0),
    ('SW-318', 'Paris', 'Karachi', 115000, 287500, 460000, 20, 0, 6, 0, 1),
    ('SW-319', 'Frankfurt', 'Karachi', 110000, 275000, 440000, 19, 0, 5, 0, 2),
    
    # Europe to Europe
    ('SW-320', 'London', 'Paris', 8000, 20000, 32000, 8, 0, 9, 0, 3),
    ('SW-321', 'London', 'Frankfurt', 9000, 22500, 36000, 10, 0, 11, 0, 4),
    ('SW-322', 'Paris', 'London', 8000, 20000, 32000, 12, 0, 13, 0, 5),
    ('SW-323', 'Paris', 'Rome', 10000, 25000, 40000, 14, 0, 15, 30, 0),
    ('SW-324', 'Frankfurt', 'Amsterdam', 6000, 15000, 24000, 16, 0, 17, 0, 1),
    
    # ==================== ASIA (ALL CITIES) ====================
    # From Karachi to Asia
    ('SW-401', 'Karachi', 'Istanbul', 85000, 212500, 340000, 6, 0, 9, 30, 2),
    ('SW-402', 'Karachi', 'Bangkok', 90000, 225000, 360000, 23, 0, 7, 0, 3),
    ('SW-403', 'Karachi', 'Kuala Lumpur', 95000, 237500, 380000, 8, 0, 12, 0, 4),
    ('SW-404', 'Karachi', 'Singapore', 105000, 262500, 420000, 9, 0, 13, 0, 5),
    ('SW-405', 'Karachi', 'Tokyo', 150000, 375000, 600000, 10, 0, 16, 0, 0),
    ('SW-406', 'Karachi', 'Seoul', 145000, 362500, 580000, 11, 0, 17, 0, 1),
    
    # From Lahore to Asia
    ('SW-407', 'Lahore', 'Kuala Lumpur', 95000, 237500, 380000, 22, 0, 6, 30, 2),
    ('SW-408', 'Lahore', 'Bangkok', 88000, 220000, 352000, 21, 0, 5, 0, 3),
    ('SW-409', 'Lahore', 'Istanbul', 82000, 205000, 328000, 20, 0, 23, 30, 4),
    ('SW-410', 'Lahore', 'Singapore', 100000, 250000, 400000, 19, 0, 23, 0, 5),
    
    # From Islamabad to Asia
    ('SW-411', 'Islamabad', 'Istanbul', 82000, 205000, 328000, 7, 0, 10, 30, 0),
    ('SW-412', 'Islamabad', 'Bangkok', 85000, 212500, 340000, 8, 0, 12, 0, 1),
    ('SW-413', 'Islamabad', 'Kuala Lumpur', 92000, 230000, 368000, 9, 0, 13, 0, 2),
    
    # Asia to Pakistan (Return flights)
    ('SW-414', 'Istanbul', 'Karachi', 85000, 212500, 340000, 10, 0, 13, 30, 3),
    ('SW-415', 'Istanbul', 'Lahore', 82000, 205000, 328000, 11, 0, 14, 30, 4),
    ('SW-416', 'Istanbul', 'Islamabad', 82000, 205000, 328000, 12, 0, 15, 30, 5),
    ('SW-417', 'Bangkok', 'Karachi', 90000, 225000, 360000, 13, 0, 17, 0, 0),
    ('SW-418', 'Kuala Lumpur', 'Karachi', 95000, 237500, 380000, 14, 0, 18, 0, 1),
    ('SW-419', 'Singapore', 'Karachi', 105000, 262500, 420000, 15, 0, 19, 0, 2),
    
    # Asia to Asia
    ('SW-420', 'Bangkok', 'Singapore', 7000, 17500, 28000, 8, 0, 9, 30, 3),
    ('SW-421', 'Singapore', 'Kuala Lumpur', 5000, 12500, 20000, 10, 0, 11, 0, 4),
    ('SW-422', 'Bangkok', 'Kuala Lumpur', 8000, 20000, 32000, 12, 0, 13, 30, 5),
    ('SW-423', 'Istanbul', 'Bangkok', 45000, 112500, 180000, 14, 0, 18, 0, 0),
    
    # ==================== AMERICAS ====================
    # From Pakistan to Americas
    ('SW-501', 'Karachi', 'New York', 180000, 450000, 720000, 8, 0, 13, 30, 1),
    ('SW-502', 'Karachi', 'Toronto', 175000, 437500, 700000, 9, 0, 14, 0, 2),
    ('SW-503', 'Karachi', 'Chicago', 170000, 425000, 680000, 10, 0, 15, 0, 3),
    ('SW-504', 'Karachi', 'Los Angeles', 190000, 475000, 760000, 11, 0, 17, 0, 4),
    
    ('SW-505', 'Lahore', 'New York', 185000, 462500, 740000, 7, 0, 12, 30, 5),
    ('SW-506', 'Lahore', 'Toronto', 180000, 450000, 720000, 8, 0, 13, 0, 0),
    
    ('SW-507', 'Islamabad', 'New York', 185000, 462500, 740000, 6, 0, 11, 30, 1),
    ('SW-508', 'Islamabad', 'Chicago', 170000, 425000, 680000, 7, 0, 12, 30, 2),
    
    # Americas to Pakistan (Return flights)
    ('SW-509', 'New York', 'Karachi', 180000, 450000, 720000, 22, 0, 20, 0, 3),
    ('SW-510', 'Toronto', 'Karachi', 175000, 437500, 700000, 23, 0, 21, 0, 4),
    ('SW-511', 'Chicago', 'Karachi', 170000, 425000, 680000, 21, 0, 19, 0, 5),
    
    # Americas to Americas
    ('SW-512', 'New York', 'Toronto', 15000, 37500, 60000, 9, 0, 10, 30, 0),
    ('SW-513', 'New York', 'Chicago', 12000, 30000, 48000, 11, 0, 12, 30, 1),
    ('SW-514', 'Toronto', 'New York', 15000, 37500, 60000, 13, 0, 14, 30, 2),
    ('SW-515', 'Los Angeles', 'New York', 25000, 62500, 100000, 15, 0, 19, 0, 3),
]

# Insert flights
for flight in flights_data:
    (flight_no, from_city, to_city, eco, biz, first, dh, dm, ah, am, aircraft_idx) = flight
    
    depart_dt = today.replace(hour=dh, minute=dm) + timedelta(days=7)
    arrive_dt = today.replace(hour=ah, minute=am) + timedelta(days=7)
    
    if arrive_dt < depart_dt:
        arrive_dt += timedelta(days=1)
    
    cursor.execute("""
        INSERT INTO flights (flight_no, origin_id, dest_id, aircraft_id, 
                           departure_dt, arrival_dt,
                           base_price_economy, base_price_business, base_price_first)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (flight_no, airport_ids[from_city], airport_ids[to_city], aircraft_list[aircraft_idx],
          depart_dt, arrive_dt, eco, biz, first))

conn.commit()

print("=" * 70)
print("DATABASE SETUP COMPLETE!")
print("=" * 70)

# Count total flights
cursor.execute("SELECT COUNT(*) as total FROM flights")
total = cursor.fetchone()
print(f"\n✅ TOTAL FLIGHTS ADDED: {total['total']}")

# Show flights by region
cursor.execute("""
    SELECT 
        CASE 
            WHEN a1.country = 'Pakistan' AND a2.country = 'Pakistan' THEN 'Domestic Pakistan'
            WHEN a1.country IN ('UAE', 'Saudi Arabia', 'Qatar', 'Kuwait', 'Oman', 'Bahrain') AND a2.country IN ('UAE', 'Saudi Arabia', 'Qatar', 'Kuwait', 'Oman', 'Bahrain') THEN 'Middle East to Middle East'
            WHEN a1.country IN ('UAE', 'Saudi Arabia', 'Qatar', 'Kuwait', 'Oman', 'Bahrain') OR a2.country IN ('UAE', 'Saudi Arabia', 'Qatar', 'Kuwait', 'Oman', 'Bahrain') THEN 'Pakistan to/from Middle East'
            WHEN a1.country IN ('UK', 'France', 'Germany', 'Netherlands', 'Spain', 'Italy') OR a2.country IN ('UK', 'France', 'Germany', 'Netherlands', 'Spain', 'Italy') THEN 'Pakistan to/from Europe'
            WHEN a1.country IN ('Turkey', 'Thailand', 'Malaysia', 'Singapore', 'Japan', 'South Korea') OR a2.country IN ('Turkey', 'Thailand', 'Malaysia', 'Singapore', 'Japan', 'South Korea') THEN 'Pakistan to/from Asia'
            WHEN a1.country IN ('USA', 'Canada') OR a2.country IN ('USA', 'Canada') THEN 'Pakistan to/from Americas'
            ELSE 'International'
        END as route_type,
        COUNT(*) as count
    FROM flights f
    JOIN airports a1 ON f.origin_id = a1.airport_id
    JOIN airports a2 ON f.dest_id = a2.airport_id
    GROUP BY route_type
    ORDER BY count DESC
""")

route_stats = cursor.fetchall()
print("\n📊 FLIGHT DISTRIBUTION BY REGION:")
print("-" * 50)
for stat in route_stats:
    print(f"  {stat['route_type']}: {stat['count']} flights")

cursor.close()
conn.close()

print("\n" + "=" * 70)
print("✅ SETUP SUCCESSFUL! Now run: python app.py")
print("=" * 70)